package com.myproject.agendamento.controller;

import com.myproject.agendamento.model.Agendamento;
import com.myproject.agendamento.repository.AgendamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RequestMapping("/agendamentos")
public class AgendamentoController {


    private AgendamentoRepository repository;

    public ResponseEntity<List<Agendamento>> getAll() {
        List<Agendamento> agendamentos = repository.findAll();
        return new ResponseEntity<>(agendamentos, HttpStatus.OK);
    }

    public ResponseEntity<Agendamento> create(@RequestBody Agendamento agendamento) {
        Agendamento novoAgendamento = repository.save(agendamento);
        return new ResponseEntity<>(novoAgendamento, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Agendamento> getById(@PathVariable Long id) {
        Agendamento agendamento = repository.findById(id).orElse(null);
        if (agendamento == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(agendamento, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Agendamento> update(@PathVariable Long id, @RequestBody Agendamento newAgendamento) {
        return repository.findById(id)
                .map(agendamento -> {
                    agendamento.setNome(newAgendamento.getNome());
                    agendamento.setDataHora(newAgendamento.getDataHora());
                    agendamento.setDescricao(newAgendamento.getDescricao());
                    Agendamento updatedAgendamento = repository.save(agendamento);
                    return new ResponseEntity<>(updatedAgendamento, HttpStatus.OK);
                })
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        repository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
