package com.myproject.agendamento.model;

import javax.persistence.*;
import java.util.Date;

public class Agendamento {

    private Long id;
    private String nome;
    private Date dataHora;
    private String descricao;

    // Getters e setters
}
